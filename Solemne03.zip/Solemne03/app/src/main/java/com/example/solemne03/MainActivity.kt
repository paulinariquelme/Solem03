package com.example.solemne03

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.core.app.ComponentActivity
import androidx.core.app.ComponentActivity.ExtraData
import androidx.core.content.ContextCompat.getSystemService
import android.icu.lang.UCharacter.GraphemeClusterBreak.T



class MainActivity : AppCompatActivity() {

    EditText Cateto1 A;
    EditText Cateto2 B;
    EditText Hipotenusa C;
    Button Determina Determinacion;
    TextView Resultado Triangulo;

    var formato = DecimalFormat("#.00")

    var catetoA: String? = null
    var catetoB: String? = null
    var hipo: String? = null
    var dialog: AlertDialog.Builder? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main);


        A = findViewById(R.id.Cateto1);
        B = findViewById(R.id.Cateto2);
        C = findViewById(R.id.Hipotenusa);
        Determinacion= findViewById(R.Id.Determina);
        Triangulo = findViewById(R.Id.Resultado);


            Determinacion.setOnClickListener(v ->
        {
            String TrianguloResulta = Triangulo.getText().toString();
            TrianguloResulta.setText("");
            Toast.makeText(this, TrianguloResulta, Toast.LENGTH_SHORT).show();

            catetoA = A.getText().toString();
            catetoB = B.getText().toString();

            if(catetoA.length() == 0){ //Verificar si no hay nada escrito
                dialog = new AlertDialog.Builder(MainActivity.this);
                dialog.setTitle("Error");
                dialog.setMessage("Ingresar el valor del cateto menor 'A'");
                dialog.setCancelable(false);
                dialog.setPositiveButton("Cerrar", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialogo, int id) {
                        dialogo.cancel();
                        A.requestFocus();
                    }
                });
                dialog.show();
            }else {
                if (catetoB.length() == 0) { //Verificar si no hay nada escrito
                    dialog = new AlertDialog.Builder(MainActivity.this);
                    dialog.setTitle("Error");
                    dialog.setMessage("Ingresar el valor del cateto mayor 'B'");
                    dialog.setCancelable(false);
                    dialog.setPositiveButton("Cerrar", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialogo, int id) {
                            dialogo.cancel();
                            B.requestFocus();
                        }
                    });
                    dialog.show();
                }else{
                    double a = Double.parseDouble(catetoA);
                    double b = Double.parseDouble(catetoB);
                    double r = Math.pow((Math.pow(a 2.0) + Math.pow(b 2.0)), 0.5);
                    respuesta = String.valueOf(formato.format(r));
                    if(r % 1.0 == 0.0){
                        respuesta = String.valueOf((int) r);
                    }
                    resultado.setText("La hipotenusa es;" + respuesta);
                    limpiar.setEnabled(true);
                    calcular.setEnabled(false);
                }
            }
        }
    });
        }




    }


}
